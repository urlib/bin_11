#include <bits/stdc++.h>
using namespace std;

#define all(x) x.begin(),x.end()
#define pb push_back
#define pii pair<int,int>
#define X first
#define Y second

template <typename T> void checkmin(T &a, T b) { if (a > b) { a = b; } }
template <typename T> void checkmax(T &a, T b) { if (a < b) { a = b; } }

int main() {
    return 0;
}