Algorithm
=========

ACM/ICPC reference 
