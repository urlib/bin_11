a , b, c
if (a + b<= vb) {
    0  a + b c
} else {
    a - (vb - b)  vb  c
}
