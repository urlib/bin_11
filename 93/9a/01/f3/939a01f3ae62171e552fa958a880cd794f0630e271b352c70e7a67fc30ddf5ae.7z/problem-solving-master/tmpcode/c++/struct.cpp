
struct solver {
    void input() {
    }

    void solve() {

    }

    void output() {

    }
};

int main () {
    solver sol;
    sol.input();
    sol.solve();
    sol.output();
    return 0;
}
