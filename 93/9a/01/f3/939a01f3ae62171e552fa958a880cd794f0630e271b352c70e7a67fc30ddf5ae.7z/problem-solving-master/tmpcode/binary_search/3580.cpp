#include <bits/stdc++.h>
#include <algorithm>
using namespace std;

const int N = 100010;
int a[N];

int main( ){
    sort(a, a + n);
    sort (a + 1, a + n + 1);
    return 0;
}
